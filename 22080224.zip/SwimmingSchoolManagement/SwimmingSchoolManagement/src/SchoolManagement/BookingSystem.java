package SchoolManagement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class BookingSystem {
    private Map<String, List<Lesson>> timetable;
    private Map<String, List<String>> coachToLessonMap;
    private Map<String, List<String>> gradeToLessonMap;
    private Map<String, Learner> learners;
    private List<String> coaches;
    private int lessonCounter = 1;

    public BookingSystem() {
        timetable = new HashMap<>();
        coachToLessonMap = new HashMap<>();
        gradeToLessonMap = new HashMap<>();
        learners = new HashMap<>();
        coaches = new ArrayList<>();

        initializeTimetable();
        initializeLearners();
        startConsole();
    }

    private void initializeTimetable() {
        String[] timeSlotsMondayWednesdayFriday = {"4-5pm", "5-6pm", "6-7pm"};
        String[] timeSlotsSaturday = {"2-3PM", "3-4PM"};
        String[] coaches = {"max", "jhon", "lisa"};
        int[] grades = {1, 2, 3, 4, 5};
        String[] days = {"monday", "wednesday", "friday", "saturday"};

        for (int i = 0; i < 4; i++) { 
            for (String day : days) {
                List<Lesson> lessons = new ArrayList<>();
                String[] timeSlots = (day.equals("saturday")) ? timeSlotsSaturday : timeSlotsMondayWednesdayFriday;
                for (String timeSlot : timeSlots) {
                    for (int grade : grades) {
                        for (String coach : coaches) {
                            Lesson lesson = new Lesson("L" + lessonCounter++, day, timeSlot, coach, grade);
                            lessons.add(lesson);
                            addToMaps(lesson);
                        }
                    }
                }
                timetable.put(day, lessons);
            }
        }
    }

    private void addToMaps(Lesson lesson) {
        coachToLessonMap.computeIfAbsent(lesson.getCoach(), k -> new ArrayList<>()).add(lesson.getId());
        gradeToLessonMap.computeIfAbsent(Integer.toString(lesson.getGradeLevel()), k -> new ArrayList<>()).add(lesson.getId());
    }

    private void initializeLearners() {
        Learner learner1 = new Learner("Olivia Doe", "Male", 7, "123-456-7890", 1);
        Learner learner2 = new Learner("Sophia Johnson", "Female", 8, "987-654-3210", 2);
        Learner learner3 = new Learner("William Brown", "Male", 6, "555-123-4567", 3);
        learners.put(learner1.getName(), learner1);
        learners.put(learner2.getName(), learner2);
        learners.put(learner3.getName(), learner3);
    }

    private void startConsole() {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;
        while (running) {
            System.out.println("----HATFIELD JUNIOR SWIMMING SCHOOL MANAGING BOOKINGS MADE BY THE LEARNERS----");
            System.out.println("        101. Book a swimming lesson");
            System.out.println("        102. Cancel/Change booking");
            System.out.println("        103. Attend the swimming lesson");
            System.out.println("        104. Monthly learner report");
            System.out.println("        105. Monthly coach report");
            System.out.println("        106. Register a new learner");
            System.out.println("        107. Exit");
          

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 101:
                    bookSwimmingLesson(scanner);
                    break;
                case 102:
                    changeOrCancelBooking(scanner);
                    break;
                case 103:
                    attendSwimmingLesson(scanner);
                    break;
                case 104:
                    monthlyLearnerReport(scanner);
                    break;
                case 105:
                    monthlyCoachReport(scanner);
                    break;
                case 106:
                    registerNewLearner(scanner);
                    break;
                case 107:
                    running = false;
                    System.out.println("Exit. Thank you:-)");
                    break;
                default:
                    System.out.println("Invalid choice. Please Enter a choice between 101 AND 107.");
            }
        }
        scanner.close();
    }


    void bookSwimmingLesson(Scanner scanner) {
        System.out.println("Enter option how to view the time table:");
        System.out.println("01. Using the day");
        System.out.println("02. Using the grade level");
        System.out.println("03. Using the coach's name");
        System.out.print("Enter the choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 01:
                viewTimetableByDay(scanner);
                break;
            case 02:
                viewTimetableByGrade(scanner);
                break;
            case 03:
                viewTimetableByCoach(scanner);
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    private void viewTimetableByDay(Scanner scanner) {
        System.out.print("Enter the day (monday, wednesday, friday, saturday): ");
        
        String day = scanner.nextLine();
        List<Lesson> lessons = timetable.getOrDefault(day, new ArrayList<>());

        // Display the header
        System.out.println("LESSON ID\tDAY\tTIME\tCOACH\tGRADE");
     
        
       

        // Display each lesson
        for (Lesson lesson : lessons) {
            System.out.println(lesson.getId() + "\t\t" + lesson.getDay() + "\t" +
                    lesson.getTimeSlot() + "\t" + lesson.getCoach() + "\t" +
                    lesson.getGradeLevel());
       
        
        }

        // Proceed to book a lesson
        bookLesson(scanner, lessons);
    }


    private void viewTimetableByGrade(Scanner scanner) {
        System.out.print("Enter the grade level: ");
        int grade = scanner.nextInt();
        scanner.nextLine();
        List<String> lessonIds = gradeToLessonMap.getOrDefault(Integer.toString(grade), new ArrayList<>());
        List<Lesson> lessons = getLessonsByIds(lessonIds);

        // Display the header
        System.out.println("LESSON ID\tDAY\tTIME\tCOACH\tGRADE");
        

        // Display each lesson
        for (Lesson lesson : lessons) {
            System.out.println(lesson.getId() + "\t\t" + lesson.getDay() + "\t" +
                    lesson.getTimeSlot() + "\t" + lesson.getCoach() + "\t" +
                    lesson.getGradeLevel());
            
        }
        

        // Proceed to book a lesson
        bookLesson(scanner, lessons);
    }


    private void viewTimetableByCoach(Scanner scanner) {
        System.out.print("Enter the name of coach: ");
        String coach = scanner.nextLine();
        List<String> lessonIds = coachToLessonMap.getOrDefault(coach, new ArrayList<>());
        List<Lesson> lessons = getLessonsByIds(lessonIds);

        // Display the header
       
        System.out.println("LESSON ID\tDAY\tTIME\tCOACH\tGRADE");
        

        // Display each lesson
        for (Lesson lesson : lessons) {
            System.out.println(lesson.getId() + "\t\t" + lesson.getDay() + "\t" +
                    lesson.getTimeSlot() + "\t" + lesson.getCoach() + "\t" +
                    lesson.getGradeLevel());
            
        }
       

        // Proceed to book a lesson
        bookLesson(scanner, lessons);
    }

    private List<Lesson> getLessonsByIds(List<String> lessonIds) {
        List<Lesson> lessons = new ArrayList<>();
        for (String lessonId : lessonIds) {
            for (List<Lesson> lessonList : timetable.values()) {
                for (Lesson lesson : lessonList) {
                    if (lesson.getId().equals(lessonId)) {
                        lessons.add(lesson);
                    }
                }
            }
        }
        return lessons;
    }

    private void displayLessons(List<Lesson> lessons) {
        for (Lesson lesson : lessons) {
            System.out.println("LESSON ID: " + lesson.getId() + ", DAY: " + lesson.getDay() +
                    ", TIME: " + lesson.getTimeSlot() + ", COACH: " + lesson.getCoach() +
                    ", GRADE: " + lesson.getGradeLevel());
        }
    }

    private void bookLesson(Scanner scanner, List<Lesson> lessons) {
        System.out.print("Enter the lesson ID for booking: ");
        String lessonId = scanner.nextLine();
        Lesson selectedLesson = null;
        for (Lesson lesson : lessons) {
            if (lesson.getId().equals(lessonId)) {
                selectedLesson = lesson;
                break;
            }
        }
        if (selectedLesson != null) {

            if (selectedLesson.getNumLearners() < 4) {

                System.out.print("Enter the name of learner: ");
                String learnerName = scanner.nextLine();
                Learner learner = learners.get(learnerName);
                if (learner != null) {
                    if (!learner.getBookedLessons().contains(lessonId)) {

                        learner.bookLesson(lessonId);
                        selectedLesson.incrementNumLearners();
                        System.out.println("Booking successful for learner " + lessonId + ".");
                    } else {
                        System.out.println("You have already booked the lesson.");
                    }
                } else {
                    System.out.println("Learner is not found.");
                }
            } else {
                System.out.println("This lesson is full.");
            }
        } else {
            System.out.println("Invalid lesson ID.");
        }
    }

    void changeOrCancelBooking(Scanner scanner) {
        System.out.print("Enter learner name: ");
        String learnerName = scanner.nextLine();
        Learner learner = learners.get(learnerName);
        if (learner != null) {
            List<String> bookedLessons = learner.getBookedLessons();
            if (!bookedLessons.isEmpty()) {
                System.out.println("Your booked lesson:");
                for (String lessonId : bookedLessons) {
                    Lesson lesson = getLessonById(lessonId);
                    System.out.println("LESSON ID: " + lessonId + ", DAY: " + lesson.getDay() +
                            ", TIME: " + lesson.getTimeSlot() + ", COACH: " + lesson.getCoach() +
                            ", GRADE: " + lesson.getGradeLevel());
                }
                System.out.print("Enter the lesson Id to change and chancel the booking: ");
                String lessonId = scanner.nextLine();
                if (bookedLessons.contains(lessonId)) {
                    Lesson lesson = getLessonById(lessonId);
                    if (lesson != null) {

                        learner.cancelBooking(lessonId);
                        lesson.decrementNumLearners();
                        System.out.println("Booking chancel for lesson " + lessonId + ".");
                    } else {
                        System.out.println("Lesson for booking.");
                    }
                } else {
                    System.out.println("You have not book this lesson.");
                }
            } else {
                System.out.println("You have not book any lesson.");
            }
        } else {
            System.out.println("Learner not found.");
        }
    }

    void attendSwimmingLesson(Scanner scanner) {
        System.out.print("Enter learner name: ");
        String learnerName = scanner.nextLine();
        Learner learner = learners.get(learnerName);
        if (learner != null) {
            List<String> bookedLessons = learner.getBookedLessons();
            if (!bookedLessons.isEmpty()) {
                System.out.println("Your booked lesson:");
                for (String lessonId : bookedLessons) {
                    Lesson lesson = getLessonById(lessonId);
                    System.out.println("LESSON ID: " + lessonId + ", DAY: " + lesson.getDay() +
                            ", TIME: " + lesson.getTimeSlot() + ", COACH: " + lesson.getCoach() +
                            ", GRADE: " + lesson.getGradeLevel());
                }
                System.out.print("Enter lesson ID to attend: ");
                String lessonId = scanner.nextLine();
                if (bookedLessons.contains(lessonId)) {
                    Lesson lesson = getLessonById(lessonId);
                    if (lesson != null) {

                        learner.attendLesson(lessonId);

                        System.out.print("Write a review for the lesson: ");
                        String review = scanner.nextLine();
                        lesson.setReview(review);

                        System.out.print("Rate the coach (1 TO 5): ");
                        int rating = scanner.nextInt();
                        scanner.nextLine();
                        lesson.setRating(rating);
                        System.out.println("Attendance And Review Recorded For Lesson " + lessonId + ".");
                    } else {
                        System.out.println("Lesson Not Found.");
                    }
                } else {
                    System.out.println("You Have Not Booked This Lesson.");
                }
            } else {
                System.out.println("You Have Not Booked Any Lessons.");
            }
        } else {
            System.out.println("Learner not found.");
        }
    }

    private Lesson getLessonById(String lessonId) {
        for (List<Lesson> lessons : timetable.values()) {
            for (Lesson lesson : lessons) {
                if (lesson.getId().equals(lessonId)) {
                    return lesson;
                }
            }
        }
        return null;
    }

    void monthlyLearnerReport(Scanner scanner) {
        System.out.print("Enter the month number: ");
        int month = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Monthly learner report for month " + month + ":");
        for (Learner learner : learners.values()) {
            System.out.println("LEARNER: " + learner.getName());
            System.out.println("BOOKED LESSONS:");
            List<String> bookedLessons = learner.getBookedLessons();
            for (String lessonId : bookedLessons) {
                Lesson lesson = getLessonById(lessonId);
                if (lesson != null) {
                    System.out.println("- LESSON ID: " + lessonId + ", DAY: " + lesson.getDay() +
                            ", TIME: " + lesson.getTimeSlot() + ", COACH: " + lesson.getCoach() +
                            ", GRADE: " + lesson.getGradeLevel());
                }
            }
            System.out.println("Number of booked lesson: " + bookedLessons.size());
        }
    }

    void monthlyCoachReport(Scanner scanner) {
        System.out.print("Enter the month number: ");
        int month = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Monthly coach report for month " + month + ":");
        for (String coach : coachToLessonMap.keySet()) {
            List<String> lessonIds = coachToLessonMap.get(coach);
            double totalRating = 0;
            int numRatings = 0;
            for (String lessonId : lessonIds) {
                Lesson lesson = getLessonById(lessonId);
                if (lesson != null && lesson.getRating() != 0) {
                    totalRating += lesson.getRating();
                    numRatings++;
                }
            }
            double averageRating = (numRatings > 0) ? totalRating / numRatings : 0;
            System.out.println("COACH: " + coach + ", AVERAGE RATING: " + averageRating);
        }
    }

    void registerNewLearner(Scanner scanner) {
        System.out.print("Enter learner name: ");
        String name = scanner.nextLine();
        System.out.print("Enter gender: ");
        String gender = scanner.nextLine();
        System.out.print("Enter age: ");
        int age = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter emergency contact : ");
        String emergencyContact = scanner.nextLine();
        System.out.print("ENTER CURRENT GRADE LEVEL: ");
        int gradeLevel = scanner.nextInt();
        scanner.nextLine();
        if (age >= 4 && age <= 11 && gradeLevel >= 0 && gradeLevel <= 5) {
            Learner newLearner = new Learner(name, gender, age, emergencyContact, gradeLevel);
            learners.put(name, newLearner);
            System.out.println("New learner registered successfully.");
        } else {
            System.out.println("Invalid age or grade level.");
        }
    }

    public static void main(String[] args) {
        new BookingSystem();
    }
}

class Lesson {
    private String id;
    private String day;
    private String timeSlot;
    private String coach;
    private int gradeLevel;
    private List<String> learners;
    private int numLearners;
    private String review;
    private int rating;

    public Lesson(String id, String day, String timeSlot, String coach, int gradeLevel) {
        this.id = id;
        this.day = day;
        this.timeSlot = timeSlot;
        this.coach = coach;
        this.gradeLevel = gradeLevel;
        this.learners = new ArrayList<>();
        this.numLearners = 0;
        this.review = "";
        this.rating = 0;
    }

    public String getId() {
        return id;
    }

    public String getDay() {
        return day;
    }

    public String getTimeSlot() {
        return timeSlot;
    }

    public String getCoach() {
        return coach;
    }

    public int getGradeLevel() {
        return gradeLevel;
    }

    public int getNumLearners() {
        return numLearners;
    }

    public void incrementNumLearners() {
        numLearners++;
    }

    public void decrementNumLearners() {
        numLearners--;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
}

class Learner {
    private String name;
    private String gender;
    private int age;
    private String emergencyContact;
    private int gradeLevel;
    private List<String> bookedLessons;

    public Learner(String name, String gender, int age, String emergencyContact, int gradeLevel) {
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.emergencyContact = emergencyContact;
        this.gradeLevel = gradeLevel;
        this.bookedLessons = new ArrayList<>();
    }

    public void bookLesson(String lessonId) {
        bookedLessons.add(lessonId);
    }

    public void cancelBooking(String lessonId) {
        bookedLessons.remove(lessonId);
    }

    public void attendLesson(String lessonId) {

    }

    public List<String> getBookedLessons() {
        return bookedLessons;
    }

    public String getName() {
        return name;
    }
}
