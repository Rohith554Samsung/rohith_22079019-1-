package SchoolManagement;

import org.junit.Test;
import static org.junit.Assert.*;

public class BookingSystemTest {
	
	   @Test
	    public void testViewTimetableByDay() {
	        
	    }

	    @Test
	    public void testViewTimetableByGrade() {
	        
	    }

	    @Test
	    public void testViewTimetableByCoach() {
	        
	    }

	    @Test
	    public void testGetLessonById() {
	        
	    }

        


}
